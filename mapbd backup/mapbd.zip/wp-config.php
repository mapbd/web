<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mapbdxyz_wp642' );

/** MySQL database username */
define( 'DB_USER', 'mapbdxyz_wp642' );

/** MySQL database password */
define( 'DB_PASSWORD', '5]S4J0(fp4' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'sw6bwgtefl0viaihcuvqfv4mvgvpqokts8dggo2q27xbqodhaixmg0ayuvkdqygn' );
define( 'SECURE_AUTH_KEY',  'k2ymtuxu9zkqw3qqy7v8ppmvykcojvrknszvuy6cvmetr3lzoxq4kdbefk05fnrj' );
define( 'LOGGED_IN_KEY',    'n6c3h1nvsfrpzouj8wikpr0hqybsruitrdo3i3exe2hmettgcte0ebp0sziaf7fz' );
define( 'NONCE_KEY',        'a2mmatqyypworcwtjrlnw2lo2ljx6rexpvysp1qwymm20ip7oihlsn7do2p528y9' );
define( 'AUTH_SALT',        'qps5ymx8igmif3zhaurm8zti02jwor17h2cko4mpqkpqgyvpwsrdqo6xbnmzdhve' );
define( 'SECURE_AUTH_SALT', 'bkwsxbvs8jf3que6wv5icfvbe6llgaz9oe8iudhmrovavpc4tpgyu9yrqqq0yfin' );
define( 'LOGGED_IN_SALT',   'fbt8l0qbtdyjfbb5tahjj2eq4hk7tkwsptjb3v0bvhxhomptmpslhyflsc5thdd5' );
define( 'NONCE_SALT',       'ctexxtntdmkzbeipvrtxborr8lntwvsbjjwyesij8cg9qyokdkbvvrw9uafjqggq' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpk1_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
